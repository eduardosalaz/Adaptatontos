module Adaptatontos {
	requires jfuzzylite;
}